
package user.bean;

import lombok.Data;

@Data
public class UserDTO {
	
	String name;
	String id;
	String pwd;

}
